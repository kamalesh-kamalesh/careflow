import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Loader2, Users } from 'lucide-react';

interface VideoConsultProps {
  roomId: string; // typically the appointment id — both participants must pass the same value
  displayName: string; // shown to the other participant
  role: 'doctor' | 'patient';
  onClose: () => void;
}

type CallStatus = 'connecting-signal' | 'waiting-for-peer' | 'connecting-media' | 'in-call' | 'ended' | 'error';

// Public STUN server for NAT traversal only — no video/audio/API keys involved.
// It never sees call content, just helps two browsers find a direct path to each other.
const ICE_SERVERS = [{ urls: 'stun:stun.l.google.com:19302' }];

export const VideoConsult: React.FC<VideoConsultProps> = ({ roomId, displayName, role, onClose }) => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  const [status, setStatus] = useState<CallStatus>('connecting-signal');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [elapsedSec, setElapsedSec] = useState(0);

  useEffect(() => {
    let cancelled = false;

    const cleanup = () => {
      wsRef.current?.close();
      pcRef.current?.close();
      localStreamRef.current?.getTracks().forEach(t => t.stop());
    };

    const start = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (cancelled) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }
        localStreamRef.current = stream;
        if (localVideoRef.current) localVideoRef.current.srcObject = stream;

        const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
        pcRef.current = pc;
        stream.getTracks().forEach(track => pc.addTrack(track, stream));

        pc.ontrack = (event) => {
          if (remoteVideoRef.current) remoteVideoRef.current.srcObject = event.streams[0];
          setStatus('in-call');
        };

        pc.onconnectionstatechange = () => {
          if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
            setStatus(prev => (prev === 'ended' ? prev : 'error'));
            setErrorMsg('Connection lost.');
          }
        };

        const proto = window.location.protocol === 'https:' ? 'wss' : 'ws';
        const ws = new WebSocket(`${proto}://${window.location.host}/ws-signal?room=${encodeURIComponent(roomId)}`);
        wsRef.current = ws;

        pc.onicecandidate = (event) => {
          if (event.candidate && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'ice-candidate', candidate: event.candidate }));
          }
        };

        ws.onopen = () => setStatus('waiting-for-peer');

        ws.onerror = () => {
          setStatus('error');
          setErrorMsg('Could not reach the signaling server. If this app is running on Vercel serverless hosting, video calls need a persistent Node server instead (e.g. Render/Railway) since Vercel functions don\'t keep WebSocket connections open.');
        };

        ws.onmessage = async (event) => {
          const msg = JSON.parse(event.data);

          if (msg.type === 'room-full') {
            setStatus('error');
            setErrorMsg('This consult room already has two participants.');
            return;
          }

          if (msg.type === 'peer-joined') {
            // The doctor's browser initiates the offer once the patient joins (and vice versa
            // if the patient opened the room first) — whoever gets notified of a new peer offers.
            setStatus('connecting-media');
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            ws.send(JSON.stringify({ type: 'offer', sdp: offer }));
            return;
          }

          if (msg.type === 'offer') {
            setStatus('connecting-media');
            await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            ws.send(JSON.stringify({ type: 'answer', sdp: answer }));
            return;
          }

          if (msg.type === 'answer') {
            await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
            return;
          }

          if (msg.type === 'ice-candidate' && msg.candidate) {
            try {
              await pc.addIceCandidate(new RTCIceCandidate(msg.candidate));
            } catch {
              // benign if it arrives before remote description is set
            }
            return;
          }

          if (msg.type === 'peer-left') {
            setStatus('ended');
            setErrorMsg('The other participant left the call.');
          }
        };
      } catch (err: any) {
        setStatus('error');
        setErrorMsg(err?.message || 'Could not access camera/microphone.');
      }
    };

    start();
    return () => {
      cancelled = true;
      cleanup();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roomId]);

  useEffect(() => {
    if (status !== 'in-call') return;
    const timer = setInterval(() => setElapsedSec(s => s + 1), 1000);
    return () => clearInterval(timer);
  }, [status]);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  const toggleMic = () => {
    localStreamRef.current?.getAudioTracks().forEach(t => (t.enabled = !t.enabled));
    setMicOn(m => !m);
  };

  const toggleCam = () => {
    localStreamRef.current?.getVideoTracks().forEach(t => (t.enabled = !t.enabled));
    setCamOn(c => !c);
  };

  const endCall = () => {
    setStatus('ended');
    wsRef.current?.close();
    pcRef.current?.close();
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    onClose();
  };

  const statusLabel: Record<CallStatus, string> = {
    'connecting-signal': 'Connecting…',
    'waiting-for-peer': `Waiting for the ${role === 'doctor' ? 'patient' : 'doctor'} to join…`,
    'connecting-media': 'Establishing video connection…',
    'in-call': `Live • ${formatTime(elapsedSec)}`,
    'ended': 'Call ended',
    'error': 'Connection issue'
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 bg-slate-900/90 border-b border-slate-800 text-white flex-shrink-0">
        <div className="flex items-center space-x-2 text-sm font-semibold">
          <Users className="w-4 h-4 text-teal-400" />
          <span>{displayName}</span>
        </div>
        <span className="text-xs font-medium text-teal-300 flex items-center space-x-1.5">
          {(status === 'connecting-signal' || status === 'connecting-media') && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
          <span>{statusLabel[status]}</span>
        </span>
      </div>

      {/* Video area */}
      <div className="flex-1 relative bg-slate-900 overflow-hidden">
        <video ref={remoteVideoRef} autoPlay playsInline className="w-full h-full object-cover bg-slate-950" />

        {status !== 'in-call' && status !== 'error' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 space-y-2">
            <Loader2 className="w-8 h-8 animate-spin text-teal-500" />
            <p className="text-sm font-medium">{statusLabel[status]}</p>
          </div>
        )}

        {status === 'error' && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-8 space-y-2">
            <p className="text-rose-400 font-bold text-sm">Something went wrong</p>
            <p className="text-slate-400 text-xs max-w-md">{errorMsg}</p>
          </div>
        )}

        {/* Local video PiP */}
        <div className="absolute bottom-24 right-4 w-32 sm:w-44 aspect-video rounded-xl overflow-hidden border-2 border-slate-700 shadow-lg bg-slate-800">
          <video ref={localVideoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-x-[-1]" />
          {!camOn && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-800 text-slate-500 text-[10px] font-semibold">
              Camera off
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center space-x-4 py-5 bg-slate-900/90 border-t border-slate-800 flex-shrink-0">
        <button
          onClick={toggleMic}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            micOn ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-rose-600 text-white'
          }`}
        >
          {micOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>
        <button
          onClick={endCall}
          className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center justify-center shadow-lg shadow-rose-600/30"
        >
          <PhoneOff className="w-6 h-6" />
        </button>
        <button
          onClick={toggleCam}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            camOn ? 'bg-slate-800 text-white hover:bg-slate-700' : 'bg-rose-600 text-white'
          }`}
        >
          {camOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};
